﻿//Free & open source. Use this software in your applications as you see fit.
namespace Hybrid;

public class Packethelper
{
    public byte[] EncryptedSessionKey;

    public byte[] EncryptedMessage;

    public byte[] initializationVector;
}
