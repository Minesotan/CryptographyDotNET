﻿//Free & open source. Use this software in your applications as you see fit.
namespace HybridGCM;

public class Packethelper
{
    public byte[] EncryptedSessionKey;

    public byte[] EncryptedMessage;

    public byte[] Nonce;

    public byte[] Tag;
}
